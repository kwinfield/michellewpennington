@extends('layout')

@section('title', "Home Page")

  

@section('about')
    <div class="mt-8">
        <p class="p-5">
            Michelle (Chelle) Pennington is a native of Cleveland, Ohio who now resides in the Queen City,
            Charlotte, NC. After moving with her husband and five children she vowed to make the most of her new
            environment and try all sorts of new endeavors, one of them being changing her career path. A life-long
            sales executive and marketer extraordinaire, Chelle decided to take a leap of faith and become an
            entrepreneur – creating and managing her successful photo booth company, The Photo Booth Lady.
            Having accomplished the unthinkable, it was time for the next challenge, becoming a best-selling author.
            This is Chelle’s debut contribution to the literary world. It is a heartfelt and brutally honest depiction of a
            challenging time in her life including the many ebbs and flows she experienced. Evolve: From Heart
            Break to Hearts Healed is Chelle’s perfect introduction to all readers – ENJOY!
        </p>
    </div>
@endsection

@section('book_photo')
    <img src="img/book.photo.1.jpeg" alt="Book Photo">
@endsection